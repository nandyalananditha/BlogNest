const express = require("express");
const router = express.Router();

const Comment =
require("../models/Comment");

// Create Comment
router.post("/", async (req, res) => {
  try {

    const comment =
      await Comment.create(req.body);

    res.status(201).json(comment);

  } catch (error) {

    res.status(500).json({
      message: error.message
    });

  }
});

// Get Comments by Post
router.get("/:postId", async (req, res) => {

  try {

    const comments =
      await Comment.find({
        postId: req.params.postId
      });

    res.json(comments);

  } catch (error) {

    res.status(500).json({
      message: error.message
    });

  }

});

module.exports = router;